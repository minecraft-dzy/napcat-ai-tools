"""MC-Agent 工具函数包。"""
